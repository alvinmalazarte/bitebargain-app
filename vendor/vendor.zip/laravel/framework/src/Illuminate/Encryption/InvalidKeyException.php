<?php namespace Illuminate\Encryption;

class InvalidKeyException extends \InvalidArgumentException {}
