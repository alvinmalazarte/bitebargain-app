<?php namespace Foo\Bar;

use Illuminate\Database\Eloquent\Model;

class EloquentModelNamespacedStub extends Model {

}
